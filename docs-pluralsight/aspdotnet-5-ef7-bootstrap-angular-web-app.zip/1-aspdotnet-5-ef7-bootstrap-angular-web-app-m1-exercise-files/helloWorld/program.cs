using System;

public class Program
{
	public void Main() 
	{
		Console.WriteLine("Hello World");
	}
}